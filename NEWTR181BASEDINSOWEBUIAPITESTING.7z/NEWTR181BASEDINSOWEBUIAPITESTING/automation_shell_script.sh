#!/bin/bash

# PRPLOS TR-181 API Testing Automation Script
# This script automates the execution of Insomnia API tests for PRPLOS Dashboard

set -e  # Exit on any error

# Configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" &> /dev/null && pwd)"
COLLECTIONS_DIR="$SCRIPT_DIR/collections"
REPORTS_DIR="$SCRIPT_DIR/reports"
LOGS_DIR="$SCRIPT_DIR/logs"

# Environment variables
DEVICE_IP="${DEVICE_IP:-192.168.1.1}"
USERNAME="${USERNAME:-admin}"
PASSWORD="${PASSWORD:-admin}"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Logging function
log() {
    echo -e "${BLUE}[$(date '+%Y-%m-%d %H:%M:%S')]${NC} $1" | tee -a "$LOGS_DIR/test_execution_${TIMESTAMP}.log"
}

error() {
    echo -e "${RED}[ERROR]${NC} $1" | tee -a "$LOGS_DIR/test_execution_${TIMESTAMP}.log"
}

success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1" | tee -a "$LOGS_DIR/test_execution_${TIMESTAMP}.log"
}

warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1" | tee -a "$LOGS_DIR/test_execution_${TIMESTAMP}.log"
}

# Function to check prerequisites
check_prerequisites() {
    log "Checking prerequisites..."
    
    # Check if Insomnia CLI is installed
    if ! command -v inso &> /dev/null; then
        error "Insomnia CLI (inso) is not installed. Please install it first:"
        echo "npm install -g @kong/insomnia-cli"
        exit 1
    fi
    
    # Check if Python is available
    if ! command -v python3 &> /dev/null; then
        error "Python3 is not installed. Please install Python 3.x"
        exit 1
    fi
    
    # Check if curl is available
    if ! command -v curl &> /dev/null; then
        error "curl is not installed. Please install curl"
        exit 1
    fi
    
    success "All prerequisites are met"
}

# Function to create directories
setup_directories() {
    log "Setting up directory structure..."
    
    mkdir -p "$COLLECTIONS_DIR"
    mkdir -p "$REPORTS_DIR"
    mkdir -p "$LOGS_DIR"
    
    success "Directory structure created"
}

# Function to test device connectivity
test_connectivity() {
    log "Testing connectivity to device at $DEVICE_IP..."
    
    if curl -s --connect-timeout 10 "http://$DEVICE_IP" > /dev/null; then
        success "Device is reachable at $DEVICE_IP"
    else
        error "Cannot reach device at $DEVICE_IP. Please check the IP address and network connectivity"
        exit 1
    fi
}

# Function to get session token
get_session_token() {
    log "Obtaining session token..."
    
    local response
    response=$(curl -s -X POST \
        -H "Content-Type: application/json" \
        -d "{\"username\":\"$USERNAME\",\"password\":\"$PASSWORD\"}" \
        "http://$DEVICE_IP/session" 2>/dev/null)
    
    if [ $? -eq 0 ] && [ -n "$response" ]; then
        local session_id
        session_id=$(echo "$response" | python3 -c "import sys, json; print(json.load(sys.stdin).get('session_id', ''))" 2>/dev/null)
        
        if [ -n "$session_id" ]; then
            export SESSION_ID="$session_id"
            success "Session token obtained: ${session_id:0:20}..."
            echo "$session_id" > "$LOGS_DIR/session_token_${TIMESTAMP}.txt"
        else
            error "Failed to extract session ID from response: $response"
            exit 1
        fi
    else
        error "Failed to authenticate with device"
        exit 1
    fi
}

# Function to run Insomnia tests
run_insomnia_tests() {
    log "Running Insomnia test collections..."
    
    local collection_file="$COLLECTIONS_DIR/PRPLOS-2000-Dashboard_Collection.json"
    
    if [ ! -f "$collection_file" ]; then
        error "Collection file not found: $collection_file"
        error "Please ensure the collection JSON file is in the collections directory"
        exit 1
    fi
    
    # Update environment variables in collection
    update_collection_env "$collection_file"
    
    # Run the collection using inso
    local report_file="$REPORTS_DIR/dashboard_test_report_${TIMESTAMP}.json"
    
    log "Executing dashboard collection tests..."
    if inso run test "$collection_file" \
        --env "Base Environment" \
        --reporter json \
        --reporter-file "$report_file" \
        --verbose; then
        
        success "Test execution completed successfully"
        generate_html_report "$report_file"
    else
        error "Test execution failed"
        exit 1
    fi
}

# Function to update collection environment variables
update_collection_env() {
    local collection_file="$1"
    log "Updating collection environment variables..."
    
    # Create a temporary modified collection with current values
    python3 -c "
import json
import sys

with open('$collection_file', 'r') as f:
    collection = json.load(f)

# Update environment variables
for resource in collection.get('resources', []):
    if resource.get('_type') == 'environment':
        resource['data']['base_url'] = 'http://$DEVICE_IP'
        resource['data']['session_id'] = '$SESSION_ID'
        resource['data']['username'] = '$USERNAME'
        resource['data']['password'] = '$PASSWORD'

with open('$collection_file', 'w') as f:
    json.dump(collection, f, indent=2)

print('Environment variables updated successfully')
" || error "Failed to update collection environment"
}

# Function to generate HTML report
generate_html_report() {
    local json_report="$1"
    local html_report="$REPORTS_DIR/dashboard_test_report_${TIMESTAMP}.html"
    
    log "Generating HTML report..."
    
    python3 "$SCRIPT_DIR/generate_report.py" "$json_report" "$html_report"
    
    if [ $? -eq 0 ]; then
        success "HTML report generated: $html_report"
    else
        warning "Failed to generate HTML report"
    fi
}

# Function to run specific test cases
run_specific_tests() {
    local test_pattern="$1"
    log "Running specific tests matching pattern: $test_pattern"
    
    # Implementation for running specific test cases
    # This would filter tests based on the pattern provided
}

# Function to cleanup
cleanup() {
    log "Performing cleanup..."
    
    # Remove temporary files if any
    if [ -n "$SESSION_ID" ]; then
        log "Invalidating session token..."
        curl -s -X DELETE \
            -H "Authorization: bearer $SESSION_ID" \
            "http://$DEVICE_IP/session" > /dev/null 2>&1 || true
    fi
    
    success "Cleanup completed"
}

# Function to display usage
usage() {
    echo "Usage: $0 [OPTIONS]"
    echo ""
    echo "Options:"
    echo "  -h, --help          Show this help message"
    echo "  -i, --ip IP         Device IP address (default: 192.168.1.1)"
    echo "  -u, --username USER Username for authentication (default: admin)"
    echo "  -p, --password PASS Password for authentication (default: admin)"
    echo "  -t, --test PATTERN  Run specific tests matching pattern"
    echo "  --dry-run          Validate setup without running tests"
    echo ""
    echo "Environment variables:"
    echo "  DEVICE_IP          Device IP address"
    echo "  USERNAME           Authentication username"
    echo "  PASSWORD           Authentication password"
    echo ""
    echo "Examples:"
    echo "  $0                                    # Run all tests with default settings"
    echo "  $0 -i 192.168.2.1 -u myuser -p mypass # Run with custom credentials"
    echo "  $0 -t \"Device Info\"                  # Run only Device Info tests"
    echo "  $0 --dry-run                         # Validate setup only"
}

# Main execution function
main() {
    local dry_run=false
    local test_pattern=""
    
    # Parse command line arguments
    while [[ $# -gt 0 ]]; do
        case $1 in
            -h|--help)
                usage
                exit 0
                ;;
            -i|--ip)
                DEVICE_IP="$2"
                shift 2
                ;;
            -u|--username)
                USERNAME="$2"
                shift 2
                ;;
            -p|--password)
                PASSWORD="$2"
                shift 2
                ;;
            -t|--test)
                test_pattern="$2"
                shift 2
                ;;
            --dry-run)
                dry_run=true
                shift
                ;;
            *)
                error "Unknown option: $1"
                usage
                exit 1
                ;;
        esac
    done
    
    echo -e "${BLUE}======================================${NC}"
    echo -e "${BLUE} PRPLOS TR-181 API Testing Framework${NC}"
    echo -e "${BLUE}======================================${NC}"
    echo ""
    
    log "Starting test execution with configuration:"
    log "  Device IP: $DEVICE_IP"
    log "  Username: $USERNAME"
    log "  Timestamp: $TIMESTAMP"
    
    # Setup trap for cleanup
    trap cleanup EXIT
    
    # Execute test sequence
    check_prerequisites
    setup_directories
    test_connectivity
    
    if [ "$dry_run" = true ]; then
        success "Dry run completed successfully. Setup is valid."
        exit 0
    fi
    
    get_session_token
    
    if [ -n "$test_pattern" ]; then
        run_specific_tests "$test_pattern"
    else
        run_insomnia_tests
    fi
    
    echo ""
    success "Test execution completed successfully!"
    echo -e "${GREEN}Reports generated in: $REPORTS_DIR${NC}"
    echo -e "${GREEN}Logs available in: $LOGS_DIR${NC}"
}

# Execute main function with all arguments
main "$@"