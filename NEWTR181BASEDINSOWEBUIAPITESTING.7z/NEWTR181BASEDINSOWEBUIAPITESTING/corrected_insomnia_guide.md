# CORRECTED: Complete Insomnia API Testing Guide for PRPLOS TR-181

## Key Corrections Made:

### 1. **Script Syntax Corrections**
- ❌ **Original used Postman syntax**: `pm.response`, `pm.environment`
- ✅ **Corrected to Insomnia syntax**: `insomnia.response`, `insomnia.environment`

### 2. **Test Script Structure**
- ❌ **Original had incorrect script placement**
- ✅ **Corrected for proper Insomnia Pre-request and After Response scripts**

### 3. **Collection Format**
- ❌ **Original didn't provide actual Insomnia JSON structure**
- ✅ **Provided complete Insomnia collection JSON with proper format**

---

## 1. **Setting Up Insomnia**

Download and install Insomnia from https://insomnia.rest/download

### Install Insomnia CLI for automation:
```bash
npm install -g @kong/insomnia-cli
```

## 2. **Project Structure**

Create a new workspace in Insomnia with the following structure:

```
PRPLOS TR-181 Testing
├── PRPLOS-1000-Authentication
├── PRPLOS-2000-Dashboard  ← PROVIDED IN COLLECTION JSON
└── PRPLOS-3000-Device-Config
```

## 3. **Environment Variables Setup**

```json
{
  "base_url": "http://192.168.1.1",
  "session_id": "",
  "username": "admin",
  "password": "admin",
  "api_timeout": "30000"
}
```

## 4. **CORRECTED Test Scripts for Insomnia**

### **Authentication Test Case - After Response Script:**

```javascript
// TC-1001: Get Session ID - After Response Script
const response = insomnia.response;
const statusCode = response.getStatusCode();

console.log('=== Authentication Test ===');
console.log(`Status Code: ${statusCode}`);
console.log(`Response Time: ${response.getTime()}ms`);

if (statusCode === 200) {
    try {
        const responseBody = JSON.parse(response.getBody());
        
        if (responseBody.session_id) {
            insomnia.environment.set('session_id', responseBody.session_id);
            console.log('✅ Authentication successful');
            console.log(`Session ID: ${responseBody.session_id.substring(0, 20)}...`);
            
            // Store authentication timestamp
            insomnia.environment.set('auth_timestamp', new Date().toISOString());
        } else {
            console.log('❌ Authentication failed: No session_id in response');
            console.log('Response:', JSON.stringify(responseBody, null, 2));
        }
    } catch (error) {
        console.log('❌ Authentication failed: Invalid JSON response');
        console.log('Error:', error.message);
    }
} else {
    console.log(`❌ Authentication failed with status code: ${statusCode}`);
    console.log('Response Body:', response.getBody());
}
```

### **Dashboard Test Cases - After Response Script:**

```javascript
// TC-2001: Get Device Information - After Response Script
const response = insomnia.response;
const request = insomnia.request;
const statusCode = response.getStatusCode();
const responseTime = response.getTime();

console.log('=== Device Info Test ===');
console.log(`Test Case: ${request.getName()}`);
console.log(`Status Code: ${statusCode}`);
console.log(`Response Time: ${responseTime}ms`);

const isSuccess = statusCode >= 200 && statusCode < 300;
console.log(`Result: ${isSuccess ? '✅ SUCCESS' : '❌ FAILURE'}`);

if (isSuccess) {
    try {
        const responseBody = JSON.parse(response.getBody());
        console.log('Device Details:');
        Object.keys(responseBody).forEach(key => {
            console.log(`  ${key}: ${responseBody[key]}`);
        });
    } catch (error) {
        console.log('Response Body (Text):');
        console.log(response.getBody());
    }
} else {
    console.log('Error Response:', response.getBody());
}

// Store test result
let results = {};
try {
    results = JSON.parse(insomnia.environment.get('test_results') || '{}');
} catch (e) {
    results = {};
}
results[request.getName()] = {
    status: isSuccess ? 'PASS' : 'FAIL',
    responseTime: responseTime
};
insomnia.environment.set('test_results', JSON.stringify(results));
```

### **Session Validation - Pre-request Script:**

```javascript
// Check session validity before making requests
const sessionId = insomnia.environment.get('session_id');

if (!sessionId) {
    console.log('⚠️ Warning: No session ID found. Please authenticate first.');
} else {
    console.log(`✅ Session ID available: ${sessionId.substring(0, 20)}...`);
}

// Log current environment
console.log('🔧 Environment Variables:');
console.log(`Base URL: ${insomnia.environment.get('base_url')}`);
console.log(`Username: ${insomnia.environment.get('username')}`);
```

## 5. **CORRECTED Endpoint Formation Guidelines**

### **Basic TR-181 Parameter Access:**
```
GET {{base_url}}/serviceElements/{TR181_Path}
```

**Examples:**
- `Device.DeviceInfo.*` → `/serviceElements/Device.DeviceInfo.*`
- `Device.Time.Client.1.Version` → `/serviceElements/Device.Time.Client.1.Version`

### **Headers (CORRECTED):**
```
Authorization: bearer {{session_id}}
Content-Type: application/json
```

### **Commands Endpoint:**
```
POST {{base_url}}/commands
Content-Type: application/json
Authorization: bearer {{session_id}}
```

## 6. **Universal Response Logger (CORRECTED for Insomnia)**

Add this to After Response Script for comprehensive logging:

```javascript
// Universal Response Logger for Insomnia
const response = insomnia.response;
const request = insomnia.request;
const testName = request.getName();
const method = request.getMethod();
const url = request.getUrl();
const statusCode = response.getStatusCode();
const responseTime = response.getTime();
const responseSize = response.getSize();

console.log('========================================');
console.log(`Test Case: ${testName}`);
console.log(`Method: ${method}`);
console.log(`URL: ${url}`);
console.log(`Status Code: ${statusCode}`);
console.log(`Response Time: ${responseTime}ms`);
console.log(`Response Size: ${responseSize} bytes`);
console.log('----------------------------------------');

// Status determination
const isSuccess = statusCode >= 200 && statusCode < 300;
console.log(`Result: ${isSuccess ? '✅ SUCCESS' : '❌ FAILURE'}`);

// Response body logging
try {
    const responseBody = JSON.parse(response.getBody());
    console.log('Response Body (JSON):');
    console.log(JSON.stringify(responseBody, null, 2));
} catch (e) {
    console.log('Response Body (Text):');
    console.log(response.getBody());
}

// Save to environment for reporting
let testResults = {};
try {
    testResults = JSON.parse(insomnia.environment.get('test_results') || '{}');
} catch (e) {
    testResults = {};
}

testResults[testName] = {
    status: isSuccess ? 'PASS' : 'FAIL',
    statusCode: statusCode,
    responseTime: responseTime,
    timestamp: new Date().toISOString()
};

insomnia.environment.set('test_results', JSON.stringify(testResults));
console.log('========================================\n');
```

## 7. **Collection Runner Setup (CORRECTED)**

### **Using Insomnia GUI:**
1. Click on the collection name
2. Select "Send All Requests"
3. Configure delay between requests: 500ms

### **Using Insomnia CLI (inso):**
```bash
# Run specific collection
inso run test "PRPLOS-2000-Dashboard Collection.json" \
    --env "Base Environment" \
    --reporter json \
    --reporter-file "reports/test_results.json"

# With custom environment
inso run test "collections/PRPLOS-2000-Dashboard Collection.json" \
    --env "Base Environment" \
    --env-var "base_url=http://192.168.2.1" \
    --verbose
```

## 8. **Test Summary Generator (CORRECTED)**

Add this to a final request's After Response Script:

```javascript
// Generate Test Summary Report for Insomnia
console.log('📊 GENERATING TEST SUMMARY REPORT');
console.log('====================================');

try {
    const results = JSON.parse(insomnia.environment.get('test_results') || '{}');
    const testNames = Object.keys(results);
    
    if (testNames.length === 0) {
        console.log('No test results found');
        return;
    }
    
    const totalTests = testNames.length;
    const passedTests = testNames.filter(name => results[name].status === 'PASS').length;
    const failedTests = totalTests - passedTests;
    const successRate = ((passedTests / totalTests) * 100).toFixed(1);
    
    console.log(`📋 Total Tests: ${totalTests}`);
    console.log(`✅ Passed: ${passedTests}`);
    console.log(`❌ Failed: ${failedTests}`);
    console.log(`📊 Success Rate: ${successRate}%`);
    console.log('------------------------------------');
    console.log('📝 Individual Test Results:');
    
    testNames.forEach(testName => {
        const result = results[testName];
        const icon = result.status === 'PASS' ? '✅' : '❌';
        console.log(`${icon} ${testName}: ${result.status} (${result.responseTime}ms)`);
    });
    
    console.log('====================================');
    
} catch (error) {
    console.log('⚠️ Error generating test summary:', error.message);
}
```

## 9. **Browser Log Collection (CORRECTED)**

For capturing REST to TR-181 conversion in browser:

```javascript
// Enhanced Network Monitoring Script
(function() {
    const originalFetch = window.fetch;
    const originalXHR = window.XMLHttpRequest.prototype.open;
    
    // Monitor fetch requests
    window.fetch = function(...args) {
        const startTime = performance.now();
        
        console.group('🔵 REST API Call (fetch)');
        console.log('URL:', args[0]);
        console.log('Options:', args[1]);
        console.groupEnd();
        
        return originalFetch.apply(this, arguments)
            .then(response => {
                const endTime = performance.now();
                
                response.clone().text().then(data => {
                    console.group('🟢 TR-181 Response');
                    console.log('URL:', args[0]);
                    console.log('Status:', response.status);
                    console.log('Time:', `${(endTime - startTime).toFixed(2)}ms`);
                    console.log('Response:', data);
                    console.groupEnd();
                });
                
                return response;
            });
    };
    
    // Monitor XMLHttpRequest
    window.XMLHttpRequest.prototype.open = function(method, url) {
        this._url = url;
        this._method = method;
        this._startTime = performance.now();
        
        console.log(`🔵 XHR: ${method} ${url}`);
        
        return originalXHR.apply(this, arguments);
    };
    
    console.log('🎯 Network monitoring enabled for TR-181 API calls');
})();
```

## 10. **Best Practices (CORRECTED)**

1. **Authentication Flow**: Always run authentication requests first
2. **Environment Variables**: Use proper Insomnia environment syntax
3. **Error Handling**: Include try-catch blocks in all scripts
4. **Logging**: Use console.log for debugging in Insomnia
5. **Test Results**: Store results in environment variables for reporting
6. **Session Management**: Check session validity before API calls

## 11. **File Organization**

```
prplos-testing/
├── collections/
│   ├── PRPLOS-1000-Authentication.json
│   ├── PRPLOS-2000-Dashboard_Collection.json  ← PROVIDED
│   └── PRPLOS-3000-Device-Config.json
├── scripts/
│   ├── run_prplos_tests.sh                    ← PROVIDED
│   ├── generate_report.py                     ← PROVIDED
│   └── insomnia_test_utils.js                 ← PROVIDED
├── reports/
│   └── (generated reports)
└── logs/
    └── (execution logs)
```

This corrected guide now provides proper Insomnia syntax and includes all the supporting files you requested. The main issues were the script syntax differences between Postman and Insomnia, which have been fully corrected.