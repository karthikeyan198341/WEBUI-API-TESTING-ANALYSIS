/**
 * PRPLOS TR-181 API Testing Utilities for Insomnia
 * 
 * This file contains utility functions and test scripts specifically designed
 * for Insomnia REST client to test PRPLOS TR-181 API endpoints.
 * 
 * Usage: Copy these functions into Insomnia's Pre-request Script or After Response Script tabs
 */

// =============================================================================
// AUTHENTICATION UTILITIES
// =============================================================================

/**
 * Authenticate with PRPLOS device and store session token
 * Use this in Pre-request Script for authentication endpoints
 */
function authenticateDevice() {
    const baseUrl = insomnia.environment.get('base_url') || 'http://192.168.1.1';
    const username = insomnia.environment.get('username') || 'admin';
    const password = insomnia.environment.get('password') || 'admin';
    
    console.log('🔐 Starting authentication process...');
    console.log(`📡 Target device: ${baseUrl}`);
    console.log(`👤 Username: ${username}`);
    
    // Note: This is a template - actual HTTP request would be made by Insomnia
    const authPayload = {
        username: username,
        password: password
    };
    
    console.log('📤 Authentication payload prepared:', JSON.stringify(authPayload, null, 2));
}

/**
 * Validate and extract session ID from authentication response
 * Use this in After Response Script for authentication endpoints
 */
function processAuthenticationResponse() {
    const response = insomnia.response;
    const statusCode = response.getStatusCode();
    
    console.log('🔍 Processing authentication response...');
    console.log(`📊 Status Code: ${statusCode}`);
    console.log(`⏱️  Response Time: ${response.getTime()}ms`);
    
    if (statusCode === 200) {
        try {
            const responseBody = JSON.parse(response.getBody());
            
            if (responseBody.session_id) {
                // Store session ID in environment
                insomnia.environment.set('session_id', responseBody.session_id);
                
                console.log('✅ Authentication successful');
                console.log(`🔑 Session ID: ${responseBody.session_id.substring(0, 20)}...`);
                console.log('💾 Session ID stored in environment variables');
                
                // Store authentication timestamp
                insomnia.environment.set('auth_timestamp', new Date().toISOString());
                
                return true;
            } else {
                console.log('❌ Authentication failed: No session_id in response');
                console.log('📄 Response body:', JSON.stringify(responseBody, null, 2));
                return false;
            }
        } catch (error) {
            console.log('❌ Authentication failed: Invalid JSON response');
            console.log('🐛 Error:', error.message);
            console.log('📄 Raw response:', response.getBody());
            return false;
        }
    } else {
        console.log(`❌ Authentication failed with status code: ${statusCode}`);
        console.log('📄 Response body:', response.getBody());
        return false;
    }
}

// =============================================================================
// TR-181 DATA MODEL UTILITIES
// =============================================================================

/**
 * Validate TR-181 parameter path format
 * Use this in Pre-request Script to validate endpoint paths
 */
function validateTR181Path(path) {
    console.log(`🔍 Validating TR-181 path: ${path}`);
    
    // Basic TR-181 path validation patterns
    const patterns = {
        device_info: /^Device\.DeviceInfo\./,
        wifi: /^Device\.WiFi\./,
        ethernet: /^Device\.Ethernet\./,
        time: /^Device\.Time\./,
        dhcp: /^Device\.DHCP\./
    };
    
    let isValid = false;
    let category = 'unknown';
    
    for (const [cat, pattern] of Object.entries(patterns)) {
        if (pattern.test(path)) {
            isValid = true;
            category = cat;
            break;
        }
    }
    
    if (isValid) {
        console.log(`✅ Valid TR-181 path detected - Category: ${category}`);
    } else {
        console.log('⚠️  Warning: Path may not follow standard TR-181 format');
    }
    
    return { isValid, category };
}

/**
 * Build service elements URL from TR-181 path
 * Use this in Pre-request Script to construct proper URLs
 */
function buildServiceElementsURL(tr181Path) {
    const baseUrl = insomnia.environment.get('base_url');
    const serviceElementsURL = `${baseUrl}/serviceElements/${tr181Path}`;
    
    console.log(`🔗 Built service elements URL: ${serviceElementsURL}`);
    
    return serviceElementsURL;
}

// =============================================================================
// RESPONSE VALIDATION UTILITIES
// =============================================================================

/**
 * Comprehensive response validator for TR-181 API calls
 * Use this in After Response Script for all TR-181 endpoints
 */
function validateTR181Response() {
    const response = insomnia.response;
    const request = insomnia.request;
    const statusCode = response.getStatusCode();
    const responseTime = response.getTime();
    const responseSize = response.getSize();
    
    console.log('=====================================');
    console.log('🧪 TR-181 API RESPONSE VALIDATION');
    console.log('=====================================');
    console.log(`📋 Test Case: ${request.getName()}`);
    console.log(`🎯 Method: ${request.getMethod()}`);
    console.log(`🔗 URL: ${request.getUrl()}`);
    console.log(`📊 Status Code: ${statusCode}`);
    console.log(`⏱️  Response Time: ${responseTime}ms`);
    console.log(`📏 Response Size: ${responseSize} bytes`);
    console.log('-------------------------------------');
    
    // Status code validation
    const isSuccess = statusCode >= 200 && statusCode < 300;
    console.log(`🎯 Result: ${isSuccess ? '✅ SUCCESS' : '❌ FAILURE'}`);
    
    // Response time validation
    const timeout = parseInt(insomnia.environment.get('api_timeout') || '30000');
    if (responseTime > timeout) {
        console.log(`⚠️  Warning: Response time (${responseTime}ms) exceeds timeout (${timeout}ms)`);
    }
    
    // Try to parse and validate response body
    try {
        const responseBody = response.getBody();
        
        if (responseBody) {
            // Attempt JSON parsing
            try {
                const jsonResponse = JSON.parse(responseBody);
                console.log('📄 Response Body (JSON):');
                console.log(JSON.stringify(jsonResponse, null, 2));
                
                // Validate TR-181 response structure
                validateTR181ResponseStructure(jsonResponse);
                
            } catch (jsonError) {
                console.log('📄 Response Body (Text):');
                console.log(responseBody);
            }
        } else {
            console.log('📄 Response Body: (empty)');
        }
    } catch (error) {
        console.log('🐛 Error processing response body:', error.message);
    }
    
    // Store test results for reporting
    storeTestResult(request.getName(), isSuccess, statusCode, responseTime);
    
    console.log('=====================================\n');
    
    return isSuccess;
}

/**
 * Validate TR-181 specific response structure
 */
function validateTR181ResponseStructure(jsonResponse) {
    console.log('🔍 Validating TR-181 response structure...');
    
    // Check for common TR-181 response patterns
    if (typeof jsonResponse === 'object') {
        const keys = Object.keys(jsonResponse);
        
        // Check if response contains TR-181 parameter names
        const tr181Pattern = /^Device\./;
        const hasTR181Params = keys.some(key => tr181Pattern.test(key));
        
        if (hasTR181Params) {
            console.log('✅ Response contains valid TR-181 parameters');
            console.log(`📊 Parameter count: ${keys.length}`);
            
            // Log parameter names
            keys.forEach(key => {
                if (tr181Pattern.test(key)) {
                    console.log(`  📌 ${key}: ${jsonResponse[key]}`);
                }
            });
        } else {
            console.log('ℹ️  Response does not contain TR-181 parameters (may be control response)');
        }
        
        // Check for error indicators
        if (jsonResponse.error || jsonResponse.errorCode) {
            console.log('❌ Error detected in response:');
            console.log(`  🚨 Error: ${jsonResponse.error || 'Unknown'}`);
            console.log(`  🔢 Error Code: ${jsonResponse.errorCode || 'N/A'}`);
        }
    }
}

// =============================================================================
// TEST RESULT STORAGE
// =============================================================================

/**
 * Store test results for collection-level reporting
 */
function storeTestResult(testName, success, statusCode, responseTime) {
    try {
        // Get existing results or initialize
        let results = {};
        try {
            results = JSON.parse(insomnia.environment.get('test_results') || '{}');
        } catch (e) {
            results = {};
        }
        
        // Store this test result
        results[testName] = {
            status: success ? 'PASS' : 'FAIL',
            statusCode: statusCode,
            responseTime: responseTime,
            timestamp: new Date().toISOString()
        };
        
        // Save back to environment
        insomnia.environment.set('test_results', JSON.stringify(results));
        
        console.log(`💾 Test result stored: ${testName} - ${success ? 'PASS' : 'FAIL'}`);
        
    } catch (error) {
        console.log('⚠️  Warning: Could not store test result:', error.message);
    }
}

// =============================================================================
// PERFORMANCE MONITORING
// =============================================================================

/**
 * Monitor API performance and log statistics
 * Use this in After Response Script to track performance
 */
function monitorPerformance() {
    const response = insomnia.response;
    const request = insomnia.request;
    const responseTime = response.getTime();
    
    console.log('📊 PERFORMANCE MONITORING');
    console.log(`⏱️  Response Time: ${responseTime}ms`);
    
    // Performance thresholds
    const thresholds = {
        excellent: 100,
        good: 500,
        acceptable: 1000,
        slow: 3000
    };
    
    let performanceRating = 'very slow';
    if (responseTime <= thresholds.excellent) {
        performanceRating = 'excellent';
    } else if (responseTime <= thresholds.good) {
        performanceRating = 'good';
    } else if (responseTime <= thresholds.acceptable) {
        performanceRating = 'acceptable';
    } else if (responseTime <= thresholds.slow) {
        performanceRating = 'slow';
    }
    
    console.log(`🎯 Performance Rating: ${performanceRating}`);
    
    // Update performance statistics
    updatePerformanceStats(responseTime);
}

/**
 * Update running performance statistics
 */
function updatePerformanceStats(responseTime) {
    try {
        let stats = {
            totalRequests: 0,
            totalTime: 0,
            minTime: Infinity,
            maxTime: 0,
            averageTime: 0
        };
        
        try {
            stats = JSON.parse(insomnia.environment.get('performance_stats') || JSON.stringify(stats));
        } catch (e) {
            // Use default stats if parsing fails
        }
        
        // Update statistics
        stats.totalRequests += 1;
        stats.totalTime += responseTime;
        stats.minTime = Math.min(stats.minTime, responseTime);
        stats.maxTime = Math.max(stats.maxTime, responseTime);
        stats.averageTime = stats.totalTime / stats.totalRequests;
        
        // Save updated statistics
        insomnia.environment.set('performance_stats', JSON.stringify(stats));
        
        console.log(`📈 Performance Stats - Avg: ${stats.averageTime.toFixed(2)}ms, Min: ${stats.minTime}ms, Max: ${stats.maxTime}ms`);
        
    } catch (error) {
        console.log('⚠️  Warning: Could not update performance statistics:', error.message);
    }
}

// =============================================================================
// COLLECTION UTILITIES
// =============================================================================

/**
 * Generate test summary report
 * Use this as a final step in collection execution
 */
function generateTestSummary() {
    console.log('📊 GENERATING TEST SUMMARY REPORT');
    console.log('=====================================');
    
    try {
        const results = JSON.parse(insomnia.environment.get('test_results') || '{}');
        const stats = JSON.parse(insomnia.environment.get('performance_stats') || '{}');
        
        const testNames = Object.keys(results);
        const totalTests = testNames.length;
        const passedTests = testNames.filter(name => results[name].status === 'PASS').length;
        const failedTests = totalTests - passedTests;
        const successRate = totalTests > 0 ? (passedTests / totalTests * 100).toFixed(1) : 0;
        
        console.log(`📋 Total Tests: ${totalTests}`);
        console.log(`✅ Passed: ${passedTests}`);
        console.log(`❌ Failed: ${failedTests}`);
        console.log(`📊 Success Rate: ${successRate}%`);
        
        if (stats.averageTime) {
            console.log(`⏱️  Average Response Time: ${stats.averageTime.toFixed(2)}ms`);
        }
        
        console.log('-------------------------------------');
        console.log('📝 Individual Test Results:');
        
        testNames.forEach(testName => {
            const result = results[testName];
            const icon = result.status === 'PASS' ? '✅' : '❌';
            console.log(`${icon} ${testName}: ${result.status} (${result.responseTime}ms)`);
        });
        
        console.log('=====================================');
        
    } catch (error) {
        console.log('⚠️  Error generating test summary:', error.message);
    }
}

/**
 * Reset test results and statistics
 * Use this at the beginning of a new test run
 */
function resetTestResults() {
    insomnia.environment.set('test_results', '{}');
    insomnia.environment.set('performance_stats', '{}');
    console.log('🔄 Test results and performance statistics reset');
}

// =============================================================================
// UTILITY FUNCTIONS
// =============================================================================

/**
 * Log environment variables for debugging
 */
function logEnvironmentVariables() {
    console.log('🔧 ENVIRONMENT VARIABLES:');
    console.log(`🌐 Base URL: ${insomnia.environment.get('base_url')}`);
    console.log(`🔑 Session ID: ${insomnia.environment.get('session_id') ? '[SET]' : '[NOT SET]'}`);
    console.log(`👤 Username: ${insomnia.environment.get('username')}`);
    console.log(`⏰ API Timeout: ${insomnia.environment.get('api_timeout')}ms`);
    console.log(`📅 Auth Timestamp: ${insomnia.environment.get('auth_timestamp') || '[NOT SET]'}`);
}

/**
 * Check if session is still valid (basic check)
 */
function checkSessionValidity() {
    const sessionId = insomnia.environment.get('session_id');
    const authTimestamp = insomnia.environment.get('auth_timestamp');
    
    if (!sessionId) {
        console.log('⚠️  Warning: No session ID found. Authentication may be required.');
        return false;
    }
    
    if (!authTimestamp) {
        console.log('ℹ️  Session ID present but no timestamp. Assuming valid.');
        return true;
    }
    
    // Check if session is older than 1 hour (configurable)
    const authTime = new Date(authTimestamp);
    const now = new Date();
    const ageMinutes = (now - authTime) / (1000 * 60);
    const maxAgeMinutes = 60; // 1 hour
    
    if (ageMinutes > maxAgeMinutes) {
        console.log(`⚠️  Warning: Session is ${ageMinutes.toFixed(1)} minutes old. Re-authentication may be needed.`);
        return false;
    }
    
    console.log(`✅ Session appears valid (${ageMinutes.toFixed(1)} minutes old)`);
    return true;
}

// =============================================================================
// EXPORT FOR DOCUMENTATION
// =============================================================================

/**
 * This object contains all available utility functions for reference
 * Copy individual functions as needed into Insomnia scripts
 */
const PRPLOS_TEST_UTILS = {
    authentication: {
        authenticateDevice,
        processAuthenticationResponse,
        checkSessionValidity
    },
    tr181: {
        validateTR181Path,
        buildServiceElementsURL,
        validateTR181Response,
        validateTR181ResponseStructure
    },
    performance: {
        monitorPerformance,
        updatePerformanceStats
    },
    reporting: {
        storeTestResult,
        generateTestSummary,
        resetTestResults
    },
    utilities: {
        logEnvironmentVariables
    }
};

// For Node.js environments (if needed)
if (typeof module !== 'undefined' && module.exports) {
    module.exports = PRPLOS_TEST_UTILS;
}