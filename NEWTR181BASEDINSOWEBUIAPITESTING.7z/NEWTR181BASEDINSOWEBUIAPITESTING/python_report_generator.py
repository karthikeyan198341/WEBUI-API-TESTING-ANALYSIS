#!/usr/bin/env python3
"""
PRPLOS TR-181 API Test Report Generator
Generates comprehensive HTML reports from Insomnia test results
"""

import json
import sys
import os
import datetime
from pathlib import Path
from typing import Dict, List, Any, Optional

class PRPLOSTestReportGenerator:
    """Generate comprehensive test reports for PRPLOS TR-181 API testing"""
    
    def __init__(self):
        self.timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.test_results = []
        self.summary_stats = {
            'total_tests': 0,
            'passed_tests': 0,
            'failed_tests': 0,
            'skipped_tests': 0,
            'total_duration': 0,
            'success_rate': 0.0
        }
    
    def load_test_results(self, json_file_path: str) -> bool:
        """Load test results from Insomnia JSON output"""
        try:
            with open(json_file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            self.parse_insomnia_results(data)
            return True
            
        except FileNotFoundError:
            print(f"Error: Test results file not found: {json_file_path}")
            return False
        except json.JSONDecodeError as e:
            print(f"Error: Invalid JSON in results file: {e}")
            return False
        except Exception as e:
            print(f"Error loading test results: {e}")
            return False
    
    def parse_insomnia_results(self, data: Dict[str, Any]) -> None:
        """Parse Insomnia test results format"""
        
        # Handle different possible JSON structures from Insomnia
        if 'results' in data:
            results = data['results']
        elif 'executions' in data:
            results = data['executions']
        else:
            # Fallback - assume the data itself contains the results
            results = data if isinstance(data, list) else [data]
        
        for result in results:
            test_case = self.parse_test_case(result)
            if test_case:
                self.test_results.append(test_case)
        
        self.calculate_summary_stats()
    
    def parse_test_case(self, result: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Parse individual test case result"""
        try:
            # Extract common fields
            test_name = result.get('name', result.get('request', {}).get('name', 'Unknown Test'))
            method = result.get('method', result.get('request', {}).get('method', 'GET'))
            url = result.get('url', result.get('request', {}).get('url', ''))
            
            # Extract response information
            response = result.get('response', {})
            status_code = response.get('code', response.get('status', 0))
            response_time = response.get('responseTime', response.get('time', 0))
            response_size = response.get('responseSize', len(str(response.get('body', ''))))
            
            # Determine test status
            status = 'passed'
            if status_code >= 400:
                status = 'failed'
            elif status_code == 0:
                status = 'skipped'
            
            # Extract test assertions if available
            assertions = []
            if 'tests' in result:
                for test in result['tests']:
                    assertions.append({
                        'name': test.get('name', ''),
                        'passed': test.get('passed', True),
                        'error': test.get('error', '')
                    })
            
            return {
                'name': test_name,
                'method': method,
                'url': url,
                'status': status,
                'status_code': status_code,
                'response_time': response_time,
                'response_size': response_size,
                'assertions': assertions,
                'response_body': response.get('body', ''),
                'error_message': result.get('error', '')
            }
            
        except Exception as e:
            print(f"Warning: Error parsing test case: {e}")
            return None
    
    def calculate_summary_stats(self) -> None:
        """Calculate summary statistics from test results"""
        self.summary_stats['total_tests'] = len(self.test_results)
        
        for test in self.test_results:
            if test['status'] == 'passed':
                self.summary_stats['passed_tests'] += 1
            elif test['status'] == 'failed':
                self.summary_stats['failed_tests'] += 1
            else:
                self.summary_stats['skipped_tests'] += 1
            
            self.summary_stats['total_duration'] += test['response_time']
        
        if self.summary_stats['total_tests'] > 0:
            self.summary_stats['success_rate'] = (
                self.summary_stats['passed_tests'] / self.summary_stats['total_tests'] * 100
            )
    
    def generate_html_report(self, output_file: str) -> bool:
        """Generate comprehensive HTML report"""
        try:
            html_content = self.build_html_content()
            
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(html_content)
            
            print(f"HTML report generated successfully: {output_file}")
            return True
            
        except Exception as e:
            print(f"Error generating HTML report: {e}")
            return False
    
    def build_html_content(self) -> str:
        """Build the complete HTML report content"""
        return f"""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PRPLOS TR-181 API Test Report</title>
    <style>
        {self.get_css_styles()}
    </style>
</head>
<body>
    <div class="container">
        {self.build_header()}
        {self.build_summary_section()}
        {self.build_detailed_results()}
        {self.build_footer()}
    </div>
    <script>
        {self.get_javascript()}
    </script>
</body>
</html>
"""
    
    def get_css_styles(self) -> str:
        """Get CSS styles for the report"""
        return """
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            background-color: #f5f5f5;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 30px;
            text-align: center;
        }
        
        .header h1 {
            font-size: 2.5em;
            margin-bottom: 10px;
        }
        
        .header .subtitle {
            font-size: 1.2em;
            opacity: 0.9;
        }
        
        .summary {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            text-align: center;
            transition: transform 0.3s ease;
        }
        
        .stat-card:hover {
            transform: translateY(-2px);
        }
        
        .stat-card h3 {
            font-size: 2.5em;
            margin-bottom: 10px;
            font-weight: bold;
        }
        
        .stat-card p {
            color: #666;
            font-size: 1.1em;
        }
        
        .passed { color: #27ae60; }
        .failed { color: #e74c3c; }
        .skipped { color: #f39c12; }
        .total { color: #3498db; }
        
        .progress-bar {
            width: 100%;
            height: 20px;
            background-color: #ecf0f1;
            border-radius: 10px;
            overflow: hidden;
            margin: 20px 0;
        }
        
        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, #27ae60, #2ecc71);
            transition: width 0.3s ease;
        }
        
        .results-section {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }
        
        .results-header {
            background: #34495e;
            color: white;
            padding: 20px;
        }
        
        .results-header h2 {
            margin-bottom: 10px;
        }
        
        .filter-buttons {
            margin-top: 15px;
        }
        
        .filter-btn {
            background: #3498db;
            color: white;
            border: none;
            padding: 8px 16px;
            margin-right: 10px;
            border-radius: 5px;
            cursor: pointer;
            transition: background 0.3s ease;
        }
        
        .filter-btn:hover {
            background: #2980b9;
        }
        
        .filter-btn.active {
            background: #27ae60;
        }
        
        .test-result {
            border-bottom: 1px solid #ecf0f1;
            padding: 20px;
            transition: background 0.3s ease;
        }
        
        .test-result:hover {
            background: #f8f9fa;
        }
        
        .test-result:last-child {
            border-bottom: none;
        }
        
        .test-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }
        
        .test-name {
            font-size: 1.3em;
            font-weight: bold;
            color: #2c3e50;
        }
        
        .test-status {
            padding: 5px 15px;
            border-radius: 20px;
            font-weight: bold;
            text-transform: uppercase;
            font-size: 0.9em;
        }
        
        .status-passed {
            background: #d5f4e6;
            color: #27ae60;
        }
        
        .status-failed {
            background: #fadbd8;
            color: #e74c3c;
        }
        
        .status-skipped {
            background: #fef9e7;
            color: #f39c12;
        }
        
        .test-details {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 15px;
        }
        
        .detail-item {
            display: flex;
            justify-content: space-between;
            padding: 8px 12px;
            background: #f8f9fa;
            border-radius: 5px;
        }
        
        .detail-label {
            font-weight: bold;
            color: #555;
        }
        
        .detail-value {
            color: #333;
            font-family: monospace;
        }
        
        .response-section {
            margin-top: 15px;
        }
        
        .response-toggle {
            background: #3498db;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 5px;
            cursor: pointer;
            margin-bottom: 10px;
        }
        
        .response-content {
            display: none;
            background: #2c3e50;
            color: #ecf0f1;
            padding: 15px;
            border-radius: 5px;
            font-family: monospace;
            font-size: 0.9em;
            white-space: pre-wrap;
            max-height: 300px;
            overflow-y: auto;
        }
        
        .footer {
            margin-top: 30px;
            text-align: center;
            color: #666;
            padding: 20px;
        }
        
        .timestamp {
            font-style: italic;
            margin-top: 10px;
        }
        
        @media (max-width: 768px) {
            .container {
                padding: 10px;
            }
            
            .header h1 {
                font-size: 2em;
            }
            
            .summary {
                grid-template-columns: 1fr;
            }
            
            .test-details {
                grid-template-columns: 1fr;
            }
        }
        """
    
    def build_header(self) -> str:
        """Build the report header"""
        return f"""
        <div class="header">
            <h1>PRPLOS TR-181 API Test Report</h1>
            <div class="subtitle">Comprehensive Dashboard API Testing Results</div>
            <div class="timestamp">Generated on {self.timestamp}</div>
        </div>
        """
    
    def build_summary_section(self) -> str:
        """Build the summary statistics section"""
        stats = self.summary_stats
        
        return f"""
        <div class="summary">
            <div class="stat-card">
                <h3 class="total">{stats['total_tests']}</h3>
                <p>Total Tests</p>
            </div>
            <div class="stat-card">
                <h3 class="passed">{stats['passed_tests']}</h3>
                <p>Passed</p>
            </div>
            <div class="stat-card">
                <h3 class="failed">{stats['failed_tests']}</h3>
                <p>Failed</p>
            </div>
            <div class="stat-card">
                <h3 class="skipped">{stats['skipped_tests']}</h3>
                <p>Skipped</p>
            </div>
            <div class="stat-card">
                <h3 class="total">{stats['success_rate']:.1f}%</h3>
                <p>Success Rate</p>
                <div class="progress-bar">
                    <div class="progress-fill" style="width: {stats['success_rate']}%"></div>
                </div>
            </div>
            <div class="stat-card">
                <h3 class="total">{stats['total_duration']:.0f}ms</h3>
                <p>Total Duration</p>
            </div>
        </div>
        """
    
    def build_detailed_results(self) -> str:
        """Build the detailed test results section"""
        results_html = """
        <div class="results-section">
            <div class="results-header">
                <h2>Detailed Test Results</h2>
                <div class="filter-buttons">
                    <button class="filter-btn active" onclick="filterTests('all')">All Tests</button>
                    <button class="filter-btn" onclick="filterTests('passed')">Passed</button>
                    <button class="filter-btn" onclick="filterTests('failed')">Failed</button>
                    <button class="filter-btn" onclick="filterTests('skipped')">Skipped</button>
                </div>
            </div>
        """
        
        for i, test in enumerate(self.test_results):
            results_html += self.build_test_result_html(test, i)
        
        results_html += "</div>"
        return results_html
    
    def build_test_result_html(self, test: Dict[str, Any], index: int) -> str:
        """Build HTML for individual test result"""
        status_class = f"status-{test['status']}"
        
        return f"""
        <div class="test-result" data-status="{test['status']}">
            <div class="test-header">
                <div class="test-name">{test['name']}</div>
                <div class="test-status {status_class}">{test['status']}</div>
            </div>
            
            <div class="test-details">
                <div class="detail-item">
                    <span class="detail-label">Method:</span>
                    <span class="detail-value">{test['method']}</span>
                </div>
                <div class="detail-item">
                    <span class="detail-label">Status Code:</span>
                    <span class="detail-value">{test['status_code']}</span>
                </div>
                <div class="detail-item">
                    <span class="detail-label">Response Time:</span>
                    <span class="detail-value">{test['response_time']}ms</span>
                </div>
                <div class="detail-item">
                    <span class="detail-label">Response Size:</span>
                    <span class="detail-value">{test['response_size']} bytes</span>
                </div>
            </div>
            
            <div class="detail-item">
                <span class="detail-label">URL:</span>
                <span class="detail-value">{test['url']}</span>
            </div>
            
            {self.build_error_section(test)}
            {self.build_response_section(test, index)}
        </div>
        """
    
    def build_error_section(self, test: Dict[str, Any]) -> str:
        """Build error section if test failed"""
        if test['status'] == 'failed' and test.get('error_message'):
            return f"""
            <div class="detail-item" style="margin-top: 15px;">
                <span class="detail-label">Error:</span>
                <span class="detail-value" style="color: #e74c3c;">{test['error_message']}</span>
            </div>
            """
        return ""
    
    def build_response_section(self, test: Dict[str, Any], index: int) -> str:
        """Build response body section"""
        if test.get('response_body'):
            # Format JSON response if possible
            try:
                if isinstance(test['response_body'], str):
                    formatted_response = json.dumps(json.loads(test['response_body']), indent=2)
                else:
                    formatted_response = json.dumps(test['response_body'], indent=2)
            except (json.JSONDecodeError, TypeError):
                formatted_response = str(test['response_body'])
            
            return f"""
            <div class="response-section">
                <button class="response-toggle" onclick="toggleResponse({index})">
                    Toggle Response Body
                </button>
                <div id="response-{index}" class="response-content">{formatted_response}</div>
            </div>
            """
        return ""
    
    def build_footer(self) -> str:
        """Build the report footer"""
        return f"""
        <div class="footer">
            <p>PRPLOS TR-181 API Testing Framework</p>
            <p>Report generated automatically from Insomnia test execution</p>
            <div class="timestamp">Generated on {self.timestamp}</div>
        </div>
        """
    
    def get_javascript(self) -> str:
        """Get JavaScript for interactive features"""
        return """
        function filterTests(status) {
            const testResults = document.querySelectorAll('.test-result');
            const filterButtons = document.querySelectorAll('.filter-btn');
            
            // Update active button
            filterButtons.forEach(btn => btn.classList.remove('active'));
            event.target.classList.add('active');
            
            // Filter test results
            testResults.forEach(test => {
                if (status === 'all' || test.dataset.status === status) {
                    test.style.display = 'block';
                } else {
                    test.style.display = 'none';
                }
            });
        }
        
        function toggleResponse(index) {
            const responseContent = document.getElementById(`response-${index}`);
            responseContent.style.display = responseContent.style.display === 'block' ? 'none' : 'block';
        }
        
        // Initialize on page load
        document.addEventListener('DOMContentLoaded', function() {
            console.log('PRPLOS Test Report loaded successfully');
        });
        """

def main():
    """Main execution function"""
    if len(sys.argv) != 3:
        print("Usage: python3 generate_report.py <input_json_file> <output_html_file>")
        sys.exit(1)
    
    input_file = sys.argv[1]
    output_file = sys.argv[2]
    
    # Create output directory if it doesn't exist
    output_dir = Path(output_file).parent
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Generate report
    generator = PRPLOSTestReportGenerator()
    
    if generator.load_test_results(input_file):
        if generator.generate_html_report(output_file):
            print(f"✅ Report generated successfully!")
            print(f"📊 Summary: {generator.summary_stats['passed_tests']}/{generator.summary_stats['total_tests']} tests passed")
            print(f"📁 Report location: {output_file}")
        else:
            print("❌ Failed to generate HTML report")
            sys.exit(1)
    else:
        print("❌ Failed to load test results")
        sys.exit(1)

if __name__ == "__main__":
    main()