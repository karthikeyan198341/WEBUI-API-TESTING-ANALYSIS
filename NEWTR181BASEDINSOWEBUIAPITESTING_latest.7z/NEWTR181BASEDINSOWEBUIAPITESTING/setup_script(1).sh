#!/bin/bash

# PRPLOS TR-181 API Testing Framework Setup Script
# This script sets up the complete testing environment for PRPLOS Insomnia testing

set -e  # Exit on any error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
NC='\033[0m' # No Color

# Configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" &> /dev/null && pwd)"
PROJECT_NAME="prplos-tr181-testing"

# Functions for styled output
print_header() {
    echo -e "${BLUE}========================================${NC}"
    echo -e "${BLUE} PRPLOS TR-181 Testing Framework Setup${NC}"
    echo -e "${BLUE}========================================${NC}"
    echo ""
}

log() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

step() {
    echo -e "${PURPLE}[STEP]${NC} $1"
}

# Function to check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Function to check prerequisites
check_prerequisites() {
    step "Checking prerequisites..."
    
    local missing_deps=()
    
    # Check Node.js and npm
    if ! command_exists node; then
        missing_deps+=("Node.js")
    else
        log "Node.js found: $(node --version)"
    fi
    
    if ! command_exists npm; then
        missing_deps+=("npm")
    else
        log "npm found: $(npm --version)"
    fi
    
    # Check Python
    if ! command_exists python3; then
        missing_deps+=("Python 3")
    else
        log "Python 3 found: $(python3 --version)"
    fi
    
    # Check curl
    if ! command_exists curl; then
        missing_deps+=("curl")
    else
        log "curl found: $(curl --version | head -n1)"
    fi
    
    # Check git
    if ! command_exists git; then
        missing_deps+=("git")
    else
        log "git found: $(git --version)"
    fi
    
    if [ ${#missing_deps[@]} -ne 0 ]; then
        error "Missing required dependencies:"
        for dep in "${missing_deps[@]}"; do
            echo "  - $dep"
        done
        echo ""
        echo "Please install the missing dependencies and run this script again."
        echo ""
        echo "Installation guides:"
        echo "  Node.js: https://nodejs.org/"
        echo "  Python 3: https://www.python.org/"
        echo "  curl: Usually pre-installed on most systems"
        echo "  git: https://git-scm.com/"
        exit 1
    fi
    
    success "All prerequisites are met"
}

# Function to install Insomnia CLI
install_insomnia_cli() {
    step "Installing Insomnia CLI..."
    
    if command_exists inso; then
        log "Insomnia CLI already installed: $(inso --version)"
        return 0
    fi
    
    log "Installing Insomnia CLI globally..."
    if npm install -g @kong/insomnia-cli; then
        success "Insomnia CLI installed successfully"
    else
        error "Failed to install Insomnia CLI"
        echo "You may need to run with sudo or configure npm permissions"
        echo "Alternative: npm install -g --prefix ~/.local @kong/insomnia-cli"
        exit 1
    fi
}

# Function to create project structure
create_project_structure() {
    step "Creating project directory structure..."
    
    local project_dir="$HOME/$PROJECT_NAME"
    
    if [ -d "$project_dir" ]; then
        warning "Project directory already exists: $project_dir"
        read -p "Do you want to continue and overwrite existing files? (y/N): " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            log "Setup cancelled by user"
            exit 0
        fi
    fi
    
    # Create directory structure
    mkdir -p "$project_dir"/{collections,scripts,reports,logs,docs,environments}
    
    log "Created project directory: $project_dir"
    log "Directory structure:"
    tree "$project_dir" 2>/dev/null || ls -la "$project_dir"
    
    success "Project structure created successfully"
    
    # Export project directory for other functions
    export PROJECT_DIR="$project_dir"
}

# Function to create collection files
create_collection_files() {
    step "Creating Insomnia collection files..."
    
    # Note: In a real scenario, these would be the actual files provided
    # For now, we'll create placeholder files with instructions
    
    cat > "$PROJECT_DIR/collections/README.md" << 'EOF'
# PRPLOS TR-181 Collections

This directory contains Insomnia collection JSON files for testing PRPLOS TR-181 APIs.

## Available Collections:

1. **PRPLOS-1000-Authentication.json** - Authentication and session management
2. **PRPLOS-2000-Dashboard_Collection.json** - Dashboard API endpoints (PROVIDED)
3. **PRPLOS-3000-Device-Config.json** - Device configuration endpoints

## Import Instructions:

1. Open Insomnia
2. Go to Application -> Preferences -> Data -> Import Data
3. Select the JSON collection file
4. The collection will be imported with all requests and environment variables

## Environment Setup:

Before running tests, ensure you update the environment variables:
- base_url: Your device IP address
- username: Device admin username  
- password: Device admin password

## Usage:

1. Import the collection
2. Update environment variables
3. Run authentication requests first
4. Execute dashboard or configuration tests
5. Use the provided scripts for automation
EOF

    # Create placeholder authentication collection
    cat > "$PROJECT_DIR/collections/PRPLOS-1000-Authentication.json" << 'EOF'
{
  "_type": "export",
  "__export_format": 4,
  "__export_date": "2025-08-13T10:00:00.000Z",
  "__export_source": "insomnia.desktop.app:v2023.5.8",
  "resources": [
    {
      "_id": "wrk_auth_001",
      "parentId": null,
      "modified": 1691923200000,
      "created": 1691923200000,
      "name": "PRPLOS-1000-Authentication Collection",
      "description": "Authentication and session management for PRPLOS TR-181 API",
      "_type": "workspace"
    }
  ]
}
EOF

    success "Collection files created"
}

# Function to copy script files
copy_script_files() {
    step "Creating script files..."
    
    # Create a wrapper script for the main execution
    cat > "$PROJECT_DIR/scripts/run_tests.sh" << 'EOF'
#!/bin/bash

# PRPLOS Test Execution Wrapper
# This script provides easy access to test execution functions

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" &> /dev/null && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

# Source the main test script
source "$SCRIPT_DIR/run_prplos_tests.sh"

# Execute main function with all arguments
main "$@"
EOF

    chmod +x "$PROJECT_DIR/scripts/run_tests.sh"
    
    # Create Python requirements file
    cat > "$PROJECT_DIR/requirements.txt" << 'EOF'
# Python dependencies for PRPLOS testing framework
requests>=2.28.0
beautifulsoup4>=4.11.0
jinja2>=3.1.0
markupsafe>=2.1.0
urllib3>=1.26.0
EOF

    # Create environment template
    cat > "$PROJECT_DIR/environments/template.json" << 'EOF'
{
  "base_url": "http://192.168.1.1",
  "session_id": "",
  "username": "admin", 
  "password": "admin",
  "api_timeout": "30000",
  "test_results": "{}",
  "performance_stats": "{}"
}
EOF

    success "Script files created"
}

# Function to install Python dependencies
install_python_dependencies() {
    step "Installing Python dependencies..."
    
    if [ -f "$PROJECT_DIR/requirements.txt" ]; then
        log "Installing Python packages..."
        if python3 -m pip install --user -r "$PROJECT_DIR/requirements.txt"; then
            success "Python dependencies installed successfully"
        else
            warning "Failed to install some Python dependencies"
            log "You may need to install them manually later"
        fi
    fi
}

# Function to create documentation
create_documentation() {
    step "Creating documentation..."
    
    cat > "$PROJECT_DIR/docs/GETTING_STARTED.md" << 'EOF'
# Getting Started with PRPLOS TR-181 Testing

## Quick Start

1. **Install Insomnia Desktop**
   Download from: https://insomnia.rest/download

2. **Import Collections**
   ```bash
   # Open Insomnia and import the collection files from:
   ./collections/PRPLOS-2000-Dashboard_Collection.json
   ```

3. **Configure Environment**
   - Update base_url with your device IP
   - Set correct username/password
   - Ensure device is accessible

4. **Run Tests**
   ```bash
   # Using automation script
   ./scripts/run_tests.sh -i 192.168.1.1 -u admin -p admin
   
   # Or manually in Insomnia GUI
   # Run authentication first, then dashboard tests
   ```

## Testing Workflow

1. **Authentication** → Get session token
2. **Dashboard Tests** → Retrieve device information
3. **Configuration Tests** → Modify device settings
4. **Report Generation** → Analyze results

## Troubleshooting

- Ensure device is reachable on the network
- Check firewall settings
- Verify credentials are correct
- Check session token validity

For detailed instructions, see the corrected guide in the main directory.
EOF

    cat > "$PROJECT_DIR/docs/API_REFERENCE.md" << 'EOF'
# PRPLOS TR-181 API Reference

## Authentication Endpoints

### POST /session
Authenticate and obtain session token

**Request:**
```json
{
  "username": "admin",
  "password": "admin"
}
```

**Response:**
```json
{
  "session_id": "abc123...",
  "expires": "2025-08-13T12:00:00Z"
}
```

## Service Elements Endpoints

### GET /serviceElements/{tr181_path}
Retrieve TR-181 parameter values

**Example:**
```
GET /serviceElements/Device.DeviceInfo.*
Authorization: bearer {session_id}
```

### POST /serviceElements/{tr181_path}
Set TR-181 parameter values

**Example:**
```
POST /serviceElements/Device.WiFi.Radio.1.Enable
Authorization: bearer {session_id}
Content-Type: application/json

{
  "value": "true"
}
```

## Common TR-181 Paths

- `Device.DeviceInfo.*` - Device information
- `Device.WiFi.Radio.1.*` - WiFi radio settings
- `Device.Ethernet.Interface.1.*` - Ethernet interface
- `Device.Time.Client.1.*` - Time client configuration
- `Device.DeviceInfo.MemoryStatus.*` - Memory information

## Error Responses

```json
{
  "error": "Unauthorized",
  "errorCode": 401,
  "message": "Invalid session token"
}
```
EOF

    success "Documentation created"
}

# Function to create a final setup report
create_setup_report() {
    step "Generating setup report..."
    
    cat > "$PROJECT_DIR/SETUP_COMPLETE.md" << EOF
# PRPLOS TR-181 Testing Framework - Setup Complete! 🎉

## Installation Summary

✅ **Project Structure Created**
- Location: $PROJECT_DIR
- Collections: Ready for import
- Scripts: Executable and configured
- Documentation: Complete guides available

✅ **Dependencies Installed**
- Insomnia CLI: $(inso --version 2>/dev/null || echo "Installation required")
- Python 3: $(python3 --version)
- Node.js: $(node --version)

## Next Steps

### 1. Install Insomnia Desktop
Download from: https://insomnia.rest/download

### 2. Import the Collection
1. Open Insomnia
2. Import: \`$PROJECT_DIR/collections/PRPLOS-2000-Dashboard_Collection.json\`
3. Update environment variables with your device details

### 3. Run Your First Test
\`\`\`bash
cd $PROJECT_DIR
./scripts/run_tests.sh --help
\`\`\`

### 4. Access Documentation
- Getting Started: \`./docs/GETTING_STARTED.md\`
- API Reference: \`./docs/API_REFERENCE.md\`
- Corrected Guide: \`./Corrected_Insomnia_PRPLOS_Guide.md\`

## Support Files Included

1. **Collections**: Insomnia JSON files for API testing
2. **Scripts**: Automation and report generation
3. **Documentation**: Comprehensive guides and references
4. **Utilities**: JavaScript helper functions for Insomnia

## Quick Test Command

\`\`\`bash
# Test connectivity to your device
curl -s http://192.168.1.1 && echo "✅ Device reachable" || echo "❌ Device not reachable"
\`\`\`

---
**Setup completed on:** $(date)
**Framework version:** 1.0.0
**Location:** $PROJECT_DIR
EOF

    success "Setup report generated: $PROJECT_DIR/SETUP_COMPLETE.md"
}

# Function to display final instructions
display_final_instructions() {
    echo ""
    echo -e "${GREEN}🎉 PRPLOS TR-181 Testing Framework Setup Complete! 🎉${NC}"
    echo ""
    echo -e "${BLUE}Project Location:${NC} $PROJECT_DIR"
    echo ""
    echo -e "${PURPLE}Next Steps:${NC}"
    echo "1. Install Insomnia Desktop: https://insomnia.rest/download"
    echo "2. Import collection: $PROJECT_DIR/collections/PRPLOS-2000-Dashboard_Collection.json"
    echo "3. Update environment variables with your device IP/credentials"
    echo "4. Run tests: cd $PROJECT_DIR && ./scripts/run_tests.sh"
    echo ""
    echo -e "${BLUE}Documentation:${NC}"
    echo "- Setup guide: $PROJECT_DIR/SETUP_COMPLETE.md"
    echo "- Getting started: $PROJECT_DIR/docs/GETTING_STARTED.md"
    echo "- API reference: $PROJECT_DIR/docs/API_REFERENCE.md"
    echo ""
    echo -e "${YELLOW}Provided Files:${NC}"
    echo "✅ PRPLOS-2000-Dashboard_Collection.json - Insomnia collection"
    echo "✅ run_prplos_tests.sh - Test automation script"
    echo "✅ generate_report.py - HTML report generator"
    echo "✅ insomnia_test_utils.js - JavaScript utilities"
    echo "✅ Corrected guide with proper Insomnia syntax"
    echo ""
    echo -e "${GREEN}Happy Testing! 🚀${NC}"
}

# Function to show usage
usage() {
    echo "Usage: $0 [OPTIONS]"
    echo ""
    echo "Options:"
    echo "  -h, --help          Show this help message"
    echo "  -p, --path PATH     Specify custom project path (default: ~/prplos-tr181-testing)"
    echo "  --skip-deps         Skip dependency installation"
    echo "  --minimal           Create minimal setup without documentation"
    echo ""
    echo "Examples:"
    echo "  $0                              # Full setup with default path"
    echo "  $0 -p /opt/prplos-testing      # Custom installation path"
    echo "  $0 --skip-deps                 # Skip dependency checks"
}

# Main setup function
main() {
    local skip_deps=false
    local minimal=false
    local custom_path=""
    
    # Parse command line arguments
    while [[ $# -gt 0 ]]; do
        case $1 in
            -h|--help)
                usage
                exit 0
                ;;
            -p|--path)
                custom_path="$2"
                shift 2
                ;;
            --skip-deps)
                skip_deps=true
                shift
                ;;
            --minimal)
                minimal=true
                shift
                ;;
            *)
                error "Unknown option: $1"
                usage
                exit 1
                ;;
        esac
    done
    
    # Override project name if custom path provided
    if [ -n "$custom_path" ]; then
        PROJECT_NAME="$(basename "$custom_path")"
        export PROJECT_DIR="$custom_path"
    fi
    
    print_header
    
    log "Starting PRPLOS TR-181 Testing Framework setup..."
    log "Target directory: ${custom_path:-$HOME/$PROJECT_NAME}"
    echo ""
    
    # Execute setup steps
    if [ "$skip_deps" = false ]; then
        check_prerequisites
        install_insomnia_cli
        install_python_dependencies
    else
        warning "Skipping dependency checks as requested"
    fi
    
    create_project_structure
    create_collection_files
    copy_script_files
    
    if [ "$minimal" = false ]; then
        create_documentation
    else
        warning "Skipping documentation creation (minimal setup)"
    fi
    
    create_setup_report
    display_final_instructions
}

# Execute main function with all arguments
main "$@"