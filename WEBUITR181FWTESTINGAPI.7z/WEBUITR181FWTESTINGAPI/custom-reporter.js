// custom-reporter.js - Enhanced response highlighting
const fs = require('fs');

class PrplOSReporter {
    constructor(newman, options) {
        newman.on('request', (err, args) => {
            const request = args.request;
            const response = args.response;
            
            // Format response body with highlighting
            const responseBody = response.stream.toString();
            const highlightedBody = this.highlightJSON(responseBody);
            
            // Log to custom format
            this.logEntry({
                timestamp: new Date().toISOString(),
                test: request.name,
                method: request.method,
                url: request.url.toString(),
                statusCode: response.code,
                responseTime: response.responseTime,
                responseBody: highlightedBody
            });
        });
    }
    
    highlightJSON(jsonString) {
        try {
            const obj = JSON.parse(jsonString);
            return JSON.stringify(obj, null, 2)
                .replace(/"([^"]+)":/g, '<span class="key">"$1":</span>')
                .replace(/: "([^"]+)"/g, ': <span class="string">"$1"</span>')
                .replace(/: (\d+)/g, ': <span class="number">$1</span>')
                .replace(/: (true|false)/g, ': <span class="boolean">$1</span>');
        } catch (e) {
            return jsonString;
        }
    }
}

module.exports = PrplOSReporter;
