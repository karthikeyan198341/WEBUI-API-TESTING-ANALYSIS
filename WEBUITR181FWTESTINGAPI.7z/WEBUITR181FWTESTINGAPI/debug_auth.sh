#!/bin/bash

DEVICE_IP="192.168.1.1"
echo "Testing authentication endpoints on $DEVICE_IP..."

# Test different endpoints
endpoints=(
    "/session"
    "/api/session"
    "/api/auth/login"
    "/auth/login"
    "/login"
    "/api/v1/auth/login"
    "/cgi-bin/login.cgi"
)

for endpoint in "${endpoints[@]}"; do
    echo -e "\n========================================"
    echo "Testing: $endpoint"
    echo "========================================"
    
    response=$(curl -s -w "\nHTTP_CODE:%{http_code}" -X POST "http://$DEVICE_IP$endpoint" \
        -H "Content-Type: application/json" \
        -d '{"username":"admin","password":"admin"}' 2>&1)
    
    http_code=$(echo "$response" | grep "HTTP_CODE:" | cut -d: -f2)
    body=$(echo "$response" | grep -v "HTTP_CODE:")
    
    echo "HTTP Code: $http_code"
    echo "Response: $body"
    
    if [[ $http_code == "200" ]] && [[ $body == *"session"* ]]; then
        echo "✅ This endpoint works!"
        break
    fi
done
