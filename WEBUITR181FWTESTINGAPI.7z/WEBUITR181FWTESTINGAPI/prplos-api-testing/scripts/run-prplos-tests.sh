[Paste the complete run-prplos-tests.sh script here from the usage guide]
