#!/usr/bin/env node
// Generate API documentation from Newman collection

const fs = require('fs');
const path = require('path');

// Read collection file
const collectionPath = process.argv[2] || 'collections/prplos-tr181-tests.json';
const collection = JSON.parse(fs.readFileSync(collectionPath, 'utf8'));

// Generate markdown documentation
let markdown = `# prplOS TR-181 API Documentation

Generated from Newman Collection: ${collection.info.name}

## Base URL
\`\`\`
{{base_url}} = http://{{device_ip}}
\`\`\`

## Authentication
All protected endpoints require Bearer token authentication:
\`\`\`
Authorization: bearer {{session_id}}
\`\`\`

## Endpoints

`;

// Function to process items recursively
function processItem(item, level = 0) {
    const indent = '  '.repeat(level);
    
    if (item.request) {
        // This is an endpoint
        const request = item.request;
        const method = request.method;
        const url = request.url.raw || request.url;
        
        markdown += `\n${indent}### ${item.name}\n\n`;
        markdown += `${indent}\`${method} ${url}\`\n\n`;
        
        if (item.request.description) {
            markdown += `${indent}${item.request.description}\n\n`;
        }
        
        // Request body
        if (request.body && request.body.raw) {
            markdown += `${indent}**Request Body:**\n`;
            markdown += `${indent}\`\`\`json\n`;
            try {
                const body = JSON.parse(request.body.raw);
                markdown += JSON.stringify(body, null, 2).split('\n').map(line => `${indent}${line}`).join('\n');
            } catch (e) {
                markdown += `${indent}${request.body.raw}`;
            }
            markdown += `\n${indent}\`\`\`\n\n`;
        }
        
        // Tests
        if (item.event) {
            const tests = item.event.find(e => e.listen === 'test');
            if (tests && tests.script && tests.script.exec) {
                markdown += `${indent}**Tests:**\n`;
                tests.script.exec.forEach(line => {
                    if (line.includes('pm.test(')) {
                        const testName = line.match(/pm\.test\(['"](.+?)['"]/);
                        if (testName) {
                            markdown += `${indent}- ${testName[1]}\n`;
                        }
                    }
                });
                markdown += '\n';
            }
        }
    } else if (item.item) {
        // This is a folder
        markdown += `\n${'#'.repeat(level + 2)} ${item.name}\n\n`;
        if (item.description) {
            markdown += `${item.description}\n\n`;
        }
        item.item.forEach(subItem => processItem(subItem, level + 1));
    }
}

// Process all items
collection.item.forEach(item => processItem(item));

// Add appendix
markdown += `
## TR-181 Parameter Reference

### Common Parameters

| Parameter | Description | Access |
|-----------|-------------|--------|
| Device.DeviceInfo.ModelName | Device model name | Non-Protected |
| Device.DeviceInfo.SoftwareVersion | Firmware version | Non-Protected |
| Device.WiFi.SSID.{i}.SSID | WiFi network name | Protected |
| Device.WiFi.AccessPoint.{i}.Security.KeyPassphrase | WiFi password | Protected |
| Device.Firewall.Enable | Firewall status | Protected |
| Device.NAT.PortMapping.{i}.* | Port forwarding rules | Protected |

### Response Format

All responses follow the TR-181 JSON format:
\`\`\`json
{
  "parameters": {
    "ParameterName": "value"
  },
  "path": "Device.Path."
}
\`\`\`

---
Generated on: ${new Date().toISOString()}
`;

// Write documentation
const outputPath = 'API-Documentation.md';
fs.writeFileSync(outputPath, markdown);
console.log(`✅ Documentation generated: ${outputPath}`);
