#!/bin/bash
# Continuous monitoring of prplOS API endpoints

DEVICE_IP="${1:-192.168.1.1}"
INTERVAL="${2:-300}"  # Default 5 minutes
WEBHOOK_URL="${3:-}"  # Optional webhook for alerts

echo "🔄 prplOS Continuous Monitoring"
echo "Device: $DEVICE_IP"
echo "Interval: ${INTERVAL}s"
echo "================================"

# Function to send alert
send_alert() {
    local message="$1"
    local status="$2"
    
    echo "[$(date)] ALERT: $message"
    
    # Send to webhook if configured
    if [ -n "$WEBHOOK_URL" ]; then
        curl -X POST "$WEBHOOK_URL" \
            -H "Content-Type: application/json" \
            -d "{\"text\":\"🚨 prplOS Alert: $message\", \"status\":\"$status\"}" \
            2>/dev/null
    fi
}

# Function to run health check
run_health_check() {
    echo "[$(date)] Running health check..."
    
    # Run minimal test set
    newman run collections/prplos-tr181-tests.json \
        --folder "Environment Setup" \
        --environment environments/prplos-env.json \
        --env-var "device_ip=$DEVICE_IP" \
        --reporters json \
        --reporter-json-export "reports/monitor-$(date +%s).json" \
        --silent
    
    if [ $? -eq 0 ]; then
        echo "[$(date)] ✅ Health check passed"
        return 0
    else
        echo "[$(date)] ❌ Health check failed"
        send_alert "Device $DEVICE_IP health check failed" "error"
        return 1
    fi
}

# Main monitoring loop
while true; do
    run_health_check
    
    echo "[$(date)] Sleeping for ${INTERVAL}s..."
    sleep "$INTERVAL"
done
