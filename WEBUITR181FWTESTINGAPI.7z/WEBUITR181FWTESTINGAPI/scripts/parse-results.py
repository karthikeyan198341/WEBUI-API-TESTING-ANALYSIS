#!/usr/bin/env python3
"""
Parse Newman JSON results and generate summary report
"""

import json
import sys
from datetime import datetime
from pathlib import Path

def parse_newman_results(json_file):
    """Parse Newman JSON results file"""
    
    with open(json_file, 'r') as f:
        data = json.load(f)
    
    # Extract summary stats
    stats = data['run']['stats']
    timings = data['run']['timings']
    
    # Parse test results
    results = {
        'summary': {
            'total': stats['tests']['total'],
            'passed': stats['tests']['total'] - stats['tests']['failed'],
            'failed': stats['tests']['failed'],
            'duration': timings['completed'] - timings['started'],
            'requests': stats['requests']['total']
        },
        'failures': [],
        'slowest': []
    }
    
    # Find failures and slow tests
    for execution in data['run']['executions']:
        test_name = execution['item']['name']
        response_time = execution['response']['responseTime']
        
        # Check for failures
        if 'assertions' in execution:
            for assertion in execution['assertions']:
                if assertion.get('error'):
                    results['failures'].append({
                        'test': test_name,
                        'assertion': assertion['assertion'],
                        'error': assertion['error']['message']
                    })
        
        # Track slow tests
        if response_time > 1000:
            results['slowest'].append({
                'test': test_name,
                'time': response_time
            })
    
    # Sort slowest tests
    results['slowest'].sort(key=lambda x: x['time'], reverse=True)
    
    return results

def generate_report(results):
    """Generate formatted report"""
    
    print("=" * 60)
    print("prplOS API Test Results Summary")
    print("=" * 60)
    print(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print()
    
    # Summary
    summary = results['summary']
    print("📊 Test Summary:")
    print(f"   Total Tests: {summary['total']}")
    print(f"   ✅ Passed: {summary['passed']}")
    print(f"   ❌ Failed: {summary['failed']}")
    print(f"   ⏱️  Duration: {summary['duration']}ms")
    print(f"   📡 Requests: {summary['requests']}")
    print()
    
    # Pass rate
    pass_rate = (summary['passed'] / summary['total'] * 100) if summary['total'] > 0 else 0
    print(f"   Pass Rate: {pass_rate:.1f}%")
    print()
    
    # Failures
    if results['failures']:
        print("❌ Failed Tests:")
        for i, failure in enumerate(results['failures'][:10], 1):
            print(f"   {i}. {failure['test']}")
            print(f"      Assertion: {failure['assertion']}")
            print(f"      Error: {failure['error']}")
            print()
    
    # Slow tests
    if results['slowest']:
        print("🐌 Slowest Tests (>1000ms):")
        for i, test in enumerate(results['slowest'][:5], 1):
            print(f"   {i}. {test['test']} - {test['time']}ms")
    
    print("=" * 60)

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python parse-results.py <results.json>")
        sys.exit(1)
    
    json_file = sys.argv[1]
    
    if not Path(json_file).exists():
        print(f"Error: File '{json_file}' not found")
        sys.exit(1)
    
    try:
        results = parse_newman_results(json_file)
        generate_report(results)
    except Exception as e:
        print(f"Error parsing results: {e}")
        sys.exit(1)
