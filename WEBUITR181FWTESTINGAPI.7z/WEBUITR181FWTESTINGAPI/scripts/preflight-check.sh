#!/bin/bash
# Pre-flight checklist for prplOS API testing

echo "🔍 prplOS API Testing - Pre-flight Check"
echo "========================================"

ERRORS=0
WARNINGS=0

# Function to check command
check_command() {
    if command -v $1 &> /dev/null; then
        echo "✅ $1 is installed ($(command -v $1))"
    else
        echo "❌ $1 is NOT installed"
        ((ERRORS++))
        return 1
    fi
}

# Function to check connectivity
check_connectivity() {
    if ping -c 1 -W 2 $1 &> /dev/null; then
        echo "✅ Device reachable at $1"
    else
        echo "⚠️  Device not responding to ping at $1"
        ((WARNINGS++))
    fi
}

# Function to check API endpoint
check_api() {
    if curl -s -o /dev/null -w "%{http_code}" --max-time 5 "http://$1/serviceElements/Device.DeviceInfo.ModelName" | grep -q "200\|401"; then
        echo "✅ API endpoint accessible at $1"
    else
        echo "❌ API endpoint NOT accessible at $1"
        ((ERRORS++))
    fi
}

# Check Node.js and npm
echo ""
echo "🔧 Checking Prerequisites..."
echo "----------------------------"
check_command node
check_command npm
check_command newman
check_command jq
check_command curl

# Check Newman reporters
echo ""
echo "📦 Checking Newman Reporters..."
echo "-------------------------------"
if npm list -g newman-reporter-htmlextra &> /dev/null; then
    echo "✅ newman-reporter-htmlextra is installed"
else
    echo "⚠️  newman-reporter-htmlextra is NOT installed"
    echo "   Run: npm install -g newman-reporter-htmlextra"
    ((WARNINGS++))
fi

# Check file structure
echo ""
echo "📁 Checking File Structure..."
echo "-----------------------------"
for dir in collections environments scripts reports; do
    if [ -d "$dir" ]; then
        echo "✅ Directory exists: $dir/"
    else
        echo "❌ Directory missing: $dir/"
        ((ERRORS++))
    fi
done

# Check required files
echo ""
echo "📄 Checking Required Files..."
echo "-----------------------------"
if [ -f "collections/prplos-tr181-tests.json" ]; then
    echo "✅ Collection file exists"
    # Validate JSON
    if jq empty collections/prplos-tr181-tests.json 2>/dev/null; then
        echo "✅ Collection file is valid JSON"
    else
        echo "❌ Collection file has invalid JSON"
        ((ERRORS++))
    fi
else
    echo "❌ Collection file missing"
    ((ERRORS++))
fi

if [ -f "environments/prplos-env.json" ]; then
    echo "✅ Environment file exists"
else
    echo "❌ Environment file missing"
    ((ERRORS++))
fi

# Check device connectivity
echo ""
echo "🌐 Checking Device Connectivity..."
echo "----------------------------------"
DEVICE_IP=$(jq -r '.values[] | select(.key=="device_ip") | .value' environments/prplos-env.json 2>/dev/null || echo "192.168.1.1")
echo "Device IP from environment: $DEVICE_IP"
check_connectivity "$DEVICE_IP"
check_api "$DEVICE_IP"

# Summary
echo ""
echo "========================================"
echo "📊 Pre-flight Check Summary"
echo "========================================"
echo "Errors: $ERRORS"
echo "Warnings: $WARNINGS"

if [ $ERRORS -eq 0 ]; then
    if [ $WARNINGS -eq 0 ]; then
        echo ""
        echo "✅ All checks passed! Ready for testing."
    else
        echo ""
        echo "⚠️  Some warnings detected, but you can proceed with testing."
    fi
    echo ""
    echo "🚀 Run tests with: ./scripts/run-prplos-tests.sh"
else
    echo ""
    echo "❌ Please fix the errors before running tests."
    exit 1
fi
