#!/bin/bash
# prplOS TR-181 API Test Runner
# This script runs all prplOS WebUI API tests and generates reports

# Configuration
DEVICE_IP="${1:-192.168.1.1}"
COLLECTION="collections/prplos-newman-collection.json"
ENV_FILE="prplos-env.json"
REPORT_DIR="test-reports/$(date +%Y%m%d_%H%M%S)"
LOG_FILE="$REPORT_DIR/test-execution.log"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Create report directory
mkdir -p "$REPORT_DIR"

# Function to print colored output
print_status() {
    echo -e "${2}[$(date +'%H:%M:%S')] ${1}${NC}" | tee -a "$LOG_FILE"
}

# Function to highlight response body in console
highlight_response() {
    echo -e "\n${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${GREEN}┃                    RESPONSE BODY                            ┃${NC}"
    echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${YELLOW}$1${NC}"
    echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}\n"
}

print_status "Starting prplOS TR-181 API Tests" "$GREEN"
print_status "Device IP: $DEVICE_IP" "$YELLOW"
print_status "Report Directory: $REPORT_DIR" "$YELLOW"

# Update environment file with device IP
jq --arg ip "$DEVICE_IP" '.values |= map(if .key == "device_ip" then .value = $ip else . end)' \
    "$ENV_FILE" > "$REPORT_DIR/env-updated.json"

# Run tests with multiple reporters
print_status "Executing Newman tests..." "$YELLOW"

newman run "$COLLECTION" \
    --environment "$REPORT_DIR/env-updated.json" \
    --reporters cli,html,htmlextra,json \
    --reporter-html-export "$REPORT_DIR/basic-report.html" \
    --reporter-htmlextra-export "$REPORT_DIR/detailed-report.html" \
    --reporter-htmlextra-title "prplOS TR-181 API Test Report" \
    --reporter-htmlextra-logs \
    --reporter-htmlextra-showEnvironmentData \
    --reporter-htmlextra-showGlobalData \
    --reporter-json-export "$REPORT_DIR/results.json" \
    --color on \
    --verbose \
    2>&1 | while IFS= read -r line; do
        echo "$line" | tee -a "$LOG_FILE"
        
        # Highlight response bodies
        if [[ "$line" == *"Response Body:"* ]]; then
            response_body=$(echo "$line" | sed 's/.*Response Body: //')
            highlight_response "$response_body" | tee -a "$LOG_FILE"
        fi
    done

# Check test results
if [ ${PIPESTATUS[0]} -eq 0 ]; then
    print_status "All tests completed successfully!" "$GREEN"
else
    print_status "Some tests failed. Check the reports for details." "$RED"
fi

# Generate summary
print_status "Generating test summary..." "$YELLOW"

# Create custom HTML summary with highlighted responses
cat > "$REPORT_DIR/summary.html" << EOF
<!DOCTYPE html>
<html>
<head>
    <title>prplOS Test Summary</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .success { color: #4CAF50; }
        .failure { color: #f44336; }
        .response { 
            background-color: #f0f0f0; 
            border: 2px solid #4CAF50; 
            padding: 10px; 
            margin: 10px 0;
            border-radius: 5px;
        }
        pre { white-space: pre-wrap; word-wrap: break-word; }
        .highlight { background-color: #FFEB3B; padding: 2px 4px; }
    </style>
</head>
<body>
    <h1>prplOS TR-181 API Test Summary</h1>
    <p>Generated: $(date)</p>
    <p>Device: $DEVICE_IP</p>
    <h2>Reports</h2>
    <ul>
        <li><a href="basic-report.html">Basic HTML Report</a></li>
        <li><a href="detailed-report.html">Detailed HTML Report (with logs)</a></li>
        <li><a href="results.json">JSON Results</a></li>
        <li><a href="test-execution.log">Execution Log</a></li>
    </ul>
</body>
</html>
EOF

print_status "Test execution completed!" "$GREEN"
print_status "Reports available at: $REPORT_DIR" "$YELLOW"

# Open reports in browser
if command -v xdg-open > /dev/null; then
    xdg-open "$REPORT_DIR/summary.html"
elif command -v open > /dev/null; then
    open "$REPORT_DIR/summary.html"
fi
