#!/bin/bash
# One-click setup script for prplOS API testing

echo "🚀 prplOS API Testing - Quick Setup"
echo "===================================="

# Create directory structure
echo "📁 Creating directory structure..."
mkdir -p prplos-api-testing/{collections,environments,scripts,reports}
cd prplos-api-testing

# Download collection file
echo "📥 Creating collection file..."
cat > collections/prplos-tr181-tests.json << 'COLLECTION_EOF'
[Paste the complete collection JSON here from the first artifact]
COLLECTION_EOF

# Create environment file
echo "📥 Creating environment file..."
cat > environments/prplos-env.json << 'ENV_EOF'
{
  "id": "prplos-tr181-env",
  "name": "prplOS TR-181 Test Environment",
  "values": [
    {
      "key": "device_ip",
      "value": "192.168.1.1",
      "type": "default",
      "enabled": true
    },
    {
      "key": "base_url",
      "value": "http://{{device_ip}}",
      "type": "default",
      "enabled": true
    },
    {
      "key": "username",
      "value": "admin",
      "type": "default",
      "enabled": true
    },
    {
      "key": "password",
      "value": "admin",
      "type": "secret",
      "enabled": true
    },
    {
      "key": "session_id",
      "value": "",
      "type": "any",
      "enabled": true
    },
    {
      "key": "test_ssid",
      "value": "TestNetwork",
      "type": "default",
      "enabled": true
    },
    {
      "key": "test_wifi_password",
      "value": "TestPassword123",
      "type": "secret",
      "enabled": true
    }
  ]
}
ENV_EOF

# Create main test runner
echo "📥 Creating test runner scripts..."
cat > scripts/run-prplos-tests.sh << 'RUNNER_EOF'
[Paste the complete run-prplos-tests.sh script here from the usage guide]
RUNNER_EOF

# Make executable
chmod +x scripts/run-prplos-tests.sh

# Install Newman
echo "📦 Installing Newman..."
npm install -g newman newman-reporter-htmlextra || {
    echo "❌ Failed to install Newman. Please install Node.js first."
    echo "Visit: https://nodejs.org"
    exit 1
}

echo ""
echo "✅ Setup Complete!"
echo ""
echo "📋 Next Steps:"
echo "1. Run all tests: ./scripts/run-prplos-tests.sh"
echo "2. Run specific module: ./scripts/run-prplos-tests.sh 192.168.1.100"
echo "3. View reports in: reports/"
echo ""
echo "Happy Testing! 🎉"
